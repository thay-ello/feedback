import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

export default function FeedbackApp() {
  const [satisfaction, setSatisfaction] = useState("");
  const [liked, setLiked] = useState("");
  const [improve, setImprove] = useState("");
  const [comment, setComment] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    if (satisfaction) {
      console.log({ satisfaction, liked, improve, comment });
      setSubmitted(true);
    } else {
      alert("Por favor, selecione seu nível de satisfação.");
    }
  };

  if (submitted) {
    return (
      <div className="max-w-xl mx-auto mt-10 text-center">
        <h2 className="text-2xl font-bold mb-4">Obrigado pelo seu feedback! 💬</h2>
        <p className="text-muted-foreground">Sua opinião é muito importante para nós.</p>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto mt-10">
      <Card>
        <CardContent className="p-6">
          <h2 className="text-xl font-semibold mb-4">Formulário de Feedback</h2>

          <div className="mb-6">
            <Label className="mb-2 block">1. Como você avalia sua satisfação com a experiência até agora?</Label>
            <RadioGroup onValueChange={setSatisfaction}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="Muito satisfeito" id="satisfeito" />
                <Label htmlFor="satisfeito">Muito satisfeito(a)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="Satisfeito" id="satisfeito2" />
                <Label htmlFor="satisfeito2">Satisfeito(a)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="Pouco satisfeito" id="pouco" />
                <Label htmlFor="pouco">Pouco satisfeito(a)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="Insatisfeito" id="insatisfeito" />
                <Label htmlFor="insatisfeito">Insatisfeito(a)</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="mb-4">
            <Label className="mb-1 block">2. O que você mais gostou?</Label>
            <Textarea value={liked} onChange={(e) => setLiked(e.target.value)} placeholder="Compartilhe o que achou mais positivo..." />
          </div>

          <div className="mb-4">
            <Label className="mb-1 block">3. O que poderia ser melhorado?</Label>
            <Textarea value={improve} onChange={(e) => setImprove(e.target.value)} placeholder="Dê sugestões de melhoria..." />
          </div>

          <div className="mb-6">
            <Label className="mb-1 block">4. Comentário geral</Label>
            <Textarea value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Escreva o que quiser compartilhar..." />
          </div>

          <Button onClick={handleSubmit} className="w-full">Enviar Feedback</Button>
        </CardContent>
      </Card>
    </div>
  );
}
