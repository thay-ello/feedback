
# Feedback App

Este é um app simples de feedback construído com React. 

## Como rodar:

1. Clone este repositório:
   ```
   git clone <URL-DO-REPOSITORIO>
   ```

2. Instale as dependências:
   ```
   npm install
   ```

3. Execute o app:
   ```
   npm start
   ```

4. Acesse a aplicação no navegador.

## Observações:
- Você pode customizar o app conforme necessário.
- Para rodar o código, certifique-se de ter o Node.js e npm instalados.
